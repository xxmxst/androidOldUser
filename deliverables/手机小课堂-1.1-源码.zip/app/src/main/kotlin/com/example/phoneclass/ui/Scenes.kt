package com.example.phoneclass.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.phoneclass.learning.*
import com.example.phoneclass.ui.theme.*
import kotlin.math.abs
import kotlinx.coroutines.flow.distinctUntilChanged

private val LocalTarget = staticCompositionLocalOf<String?> { null }
private val LocalDiagram = staticCompositionLocalOf { false }
private fun Modifier.target(tag: String, focus: String?): Modifier = this.testTag("sim_$tag").then(
    if (tag == focus) Modifier.border(3.dp, Blue, RoundedCornerShape(14.dp)).background(Color(0xFFEDF4FF), RoundedCornerShape(14.dp)) else Modifier
)

@Composable
private fun SimButton(text: String, tag: String, click: (PracticeEvent) -> Unit) {
    val manager = LocalFocusManager.current
    OutlinedButton(onClick = { manager.clearFocus(); click(PracticeEvent.Click(tag)) }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp).target(tag, LocalTarget.current), shape = RoundedCornerShape(14.dp), contentPadding = PaddingValues(12.dp)) { Text(text, style = MaterialTheme.typography.bodyMedium) }
}

@Composable
private fun MoreButton(text: String, click: (PracticeEvent) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        OutlinedButton(onClick = { click(PracticeEvent.Click("more")) }, modifier = Modifier.heightIn(min = 56.dp).target("more", LocalTarget.current), shape = RoundedCornerShape(14.dp)) { Text(text, style = MaterialTheme.typography.bodyMedium) }
    }
}

@Composable
private fun SimSwitch(label: String, checked: Boolean, tag: String = "toggle", click: (PracticeEvent) -> Unit) {
    Row(Modifier.fillMaxWidth().target(tag, LocalTarget.current).clip(RoundedCornerShape(14.dp)).toggleable(value = checked, role = Role.Switch, onValueChange = { click(PracticeEvent.Click(tag)) }).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(if (checked) "已开启" else "已关闭", style = MaterialTheme.typography.bodySmall, color = if (checked) Green else Muted)
        }
        Switch(checked = checked, onCheckedChange = null)
    }
}

@Composable
private fun SimInput(label: String, state: PracticeState, click: (PracticeEvent) -> Unit, password: Boolean = false) {
    val focusManager = LocalFocusManager.current
    OutlinedTextField(value = state.text, onValueChange = { click(PracticeEvent.Input(it)) }, label = { Text(label, style = MaterialTheme.typography.bodySmall) }, modifier = Modifier.fillMaxWidth().target("text_input", LocalTarget.current), textStyle = MaterialTheme.typography.bodyLarge,
        singleLine = true, readOnly = LocalDiagram.current, keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.NumberPassword else KeyboardType.Text, imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None, shape = RoundedCornerShape(14.dp))
}

@Composable
private fun SimSlider(label: String, value: Float, tag: String, range: ClosedFloatingPointRange<Float> = 0f..100f, click: (PracticeEvent) -> Unit) {
    Column(Modifier.fillMaxWidth().target("${tag}_group", null).padding(8.dp)) {
        Text("$label  ${value.toInt()}${if (tag == "font_slider") "" else "%"}", style = MaterialTheme.typography.bodyMedium)
        Slider(value = value.coerceIn(range), onValueChange = { click(PracticeEvent.Adjust(tag, it)) }, valueRange = range, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp).target(tag, LocalTarget.current))
    }
}

@Composable
private fun Notice(text: String) {
    Surface(color = Color(0xFFF0F4F8), shape = RoundedCornerShape(14.dp)) { Text(text, Modifier.fillMaxWidth().padding(14.dp), style = MaterialTheme.typography.bodySmall, color = Ink) }
}

@Composable
fun SceneUi(scene: Scene, state: PracticeState, focus: String?, onEvent: (PracticeEvent) -> Unit, diagram: Boolean = false) {
    if (scene == Scene.WECHAT) { WechatSceneUi(state, focus, onEvent, diagram); return }
    val actualFocus = when {
        scene == Scene.TAP && state.page == "album" -> "back"
        scene == Scene.NAVIGATION && state.page == "album" && "opened" !in state.achieved -> "open_photo"
        scene == Scene.SEND_PHOTO && state.page == "attachments" -> "album"
        scene == Scene.SCAN && state.page == "menu" -> "scan"
        scene == Scene.PERMISSION && state.page == "permissions" -> "allow"
        scene == Scene.WIFI && state.page == "password" && state.text.isEmpty() -> "text_input"
        else -> focus
    }.takeIf { focus != null }
    CompositionLocalProvider(LocalTarget provides actualFocus, LocalDiagram provides diagram) {
        Surface(color = Color.White, shape = RoundedCornerShape(24.dp), border = BorderStroke(1.dp, Color(0xFFCAD4E2))) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(if (diagram) "图解示意" else "练习页面", style = MaterialTheme.typography.labelMedium, color = Blue)
                Text(when (scene) {
                    Scene.WIFI -> "WLAN"
                    Scene.DATA -> "网络连接"
                    Scene.BUDGET -> "流量管理 · 套餐设置"
                    Scene.APP_NETWORK -> "应用联网 · 乐看视频"
                    Scene.PERMISSION -> "安心生活 · 相机权限"
                    Scene.NOTIFICATION -> "通知管理 · 社区消息"
                    Scene.SOUND -> "声音与显示"
                    Scene.FONT -> "字体大小"
                    Scene.CARE -> "简易与关怀设置"
                    Scene.CHAT, Scene.SEND_PHOTO -> "聊天对象：家人（示例）"
                    Scene.PHOTO -> "家庭相册"
                    Scene.INSTALL -> "应用市场（示例）"
                    else -> "邻里生活（示例）"
                }, style = MaterialTheme.typography.titleMedium)
                HorizontalDivider(color = Color(0xFFE5EAF0))
                when (scene) {
                    Scene.WECHAT -> Unit
                    Scene.TAP -> if (state.page == "main") {
                        AppTile("相册", "album", onClick = { onEvent(PracticeEvent.Click("album")) }, onLong = { onEvent(PracticeEvent.Gesture("long")) })
                        Notice("点一下打开；按住一会儿，看看更多操作。")
                    } else {
                        PhotoArt(Modifier.fillMaxWidth().height(150.dp))
                        Notice("相册已经打开了。")
                        SimButton("‹ 返回图标页面", "back", onEvent)
                    }
                    Scene.VERTICAL -> {
                        val listScroll = rememberScrollState(if (diagram && state.index > 0) 1000 else 0)
                        LaunchedEffect(listScroll, diagram) {
                            if (!diagram) snapshotFlow { listScroll.value > 60 }.distinctUntilChanged().collect { moved -> if (moved) onEvent(PracticeEvent.Gesture("scroll")) }
                        }
                        Column(Modifier.fillMaxWidth().height(288.dp).border(1.dp, Color(0xFFCDD5E1), RoundedCornerShape(12.dp)).verticalScroll(listScroll).testTag("sim_scroll_list"), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("邻里公告", "今日天气", "便民电话", "健康提醒", "活动安排", "菜谱分享", "家庭相册").forEach { title ->
                                if (title == "家庭相册") SimButton("家庭相册  ›", "family_album", onEvent)
                                else Text(title, Modifier.fillMaxWidth().padding(18.dp), style = MaterialTheme.typography.bodyMedium)
                                HorizontalDivider()
                            }
                        }
                        Notice("在上方列表里面向上滑动，找找下面还有什么。")
                    }
                    Scene.HORIZONTAL -> {
                        var drag by remember { mutableFloatStateOf(0f) }
                        Column(Modifier.fillMaxWidth().testTag("sim_pager").pointerInput(Unit) {
                            detectHorizontalDragGestures(onDragStart = { drag = 0f }, onDragEnd = { if (abs(drag) > 40.dp.toPx()) onEvent(PracticeEvent.Gesture(if (drag < 0) "left" else "right")) }, onHorizontalDrag = { change, amount -> change.consume(); drag += amount })
                        }, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            PhotoArt(Modifier.fillMaxWidth().height(190.dp), state.index)
                            Text(listOf("早上好", "出门走一走", "平安到家")[state.index], style = MaterialTheme.typography.titleLarge)
                            Text((0..2).joinToString("  ") { if (it == state.index) "●" else "○" }, color = Blue, modifier = Modifier.semantics { contentDescription = "第 ${state.index + 1} 张，共三张" })
                        }
                        Notice("在图片上左右滑动。小圆点表示所在页。")
                    }
                    Scene.NAVIGATION -> {
                        when (state.page) {
                            "main" -> AppTile("相册", "album", onClick = { onEvent(PracticeEvent.Click("album")) })
                            "album" -> { PhotoArt(Modifier.fillMaxWidth().height(130.dp)); SimButton("打开照片", "open_photo", onEvent) }
                            "photo" -> { PhotoArt(Modifier.fillMaxWidth().height(220.dp)); Notice("现在在照片详情。试着返回相册。") }
                        }
                        HorizontalDivider()
                        SimButton("‹ 返回（模拟）", "nav_back", onEvent)
                        SimButton("○ 桌面（模拟）", "nav_home", onEvent)
                    }
                    Scene.MENU -> when (state.page) {
                        "main", "menu" -> {
                            MoreButton("⋮ 更多", onEvent)
                            if (state.page == "menu") { Notice("更多菜单"); SimButton("设置  ›", "settings", onEvent) }
                            else Notice("右上角常能找到更多菜单。具体位置随软件不同。")
                        }
                        "settings" -> { Notice("设置"); SimButton("字体大小  ›", "font_entry", onEvent); SimButton("‹ 返回", "back", onEvent) }
                        else -> { Text("这里可以调整字体大小。", style = MaterialTheme.typography.bodyLarge); SimButton("‹ 返回", "back", onEvent) }
                    }
                    Scene.SWITCH -> {
                        SimSwitch("阅读提醒", state.enabled, click = onEvent)
                        SimButton("恢复默认", "reset_dialog", onEvent)
                    }
                    Scene.WIFI -> {
                        SimSwitch("WLAN", state.enabled, click = onEvent)
                        if (state.enabled) {
                            if (state.page == "password") {
                                Notice("温暖的家 · 需要密码\n本课练习密码：12345678")
                                SimInput("请输入网络密码", state, onEvent, password = true)
                                SimButton("连接", "connect", onEvent)
                                SimButton("取消", "cancel", onEvent)
                            } else {
                                SimButton(if (state.connected) "温暖的家  ✓ 已连接" else "温暖的家  ▣ 需要密码", "network", onEvent)
                                Notice(if (state.connected) "连接成功，家里的网络已选中。" else "附近的网络\n邻居的网络 · 需要密码\n请选自己认识的网络。")
                            }
                        } else Notice("WLAN 已关闭。打开以后才能看到网络列表。")
                    }
                    Scene.DATA -> {
                        SimSwitch("移动数据", state.enabled, click = onEvent)
                        SimSwitch("连接家里 Wi-Fi", state.secondary, "wifi_toggle", onEvent)
                        Notice("当前通道：" + if (state.secondary) "家里 Wi-Fi" else if (state.enabled) "手机卡移动数据" else "没有网络")
                        SimButton("试着上网", "try_network", onEvent)
                    }
                    Scene.BUDGET -> {
                        Notice("本月已用：${"%.1f".format(java.util.Locale.ROOT, state.used)}GB\n套餐限额：${if (state.budget == 0) "未设置" else "${state.budget}GB"}")
                        SimButton(if (state.budget == 2) "✓ 2GB 套餐限额" else "2GB 套餐限额", "budget_2", onEvent)
                        SimButton(if (state.budget == 5) "✓ 5GB 套餐限额" else "5GB 套餐限额", "budget_5", onEvent)
                        SimSwitch("超额停止移动数据", state.enabled, click = onEvent)
                        SimButton("模拟下载 0.3GB", "download", onEvent)
                        if (state.enabled && state.budget > 0 && state.used > state.budget) Notice("移动数据已停止 · 不能继续下载")
                    }
                    Scene.APP_NETWORK -> {
                        SimSwitch("移动数据", state.enabled, click = onEvent)
                        SimSwitch("WLAN", state.secondary, "wifi_toggle", onEvent)
                        SimButton("用移动数据试用", "test_mobile", onEvent)
                        SimButton("用 WLAN 试用", "test_wifi", onEvent)
                    }
                    Scene.PERMISSION -> {
                        if (state.page == "permissions") {
                            Notice("相机权限：${if (state.permission == true) "已允许" else "未允许"}")
                            SimButton("允许使用相机", "allow", onEvent)
                            SimButton("拒绝使用相机", "deny", onEvent)
                            SimButton("‹ 返回", "back", onEvent)
                        } else {
                            if (state.page == "scanning") QrArt(Modifier.fillMaxWidth().height(160.dp))
                            Notice("相机权限：${when(state.permission) { true -> "已允许"; false -> "已拒绝"; null -> "尚未选择" }}")
                            SimButton("打开模拟扫码", "open_scan", onEvent)
                            SimButton("权限设置  ›", "permission_settings", onEvent)
                        }
                    }
                    Scene.NOTIFICATION -> {
                        SimSwitch("允许社区消息通知", state.enabled, click = onEvent)
                        SimButton("发送一条模拟通知", "notify", onEvent)
                        if (state.secondary) Notice("新通知\n社区活动明天开始。")
                        else Notice("这里还没有通知卡片。")
                    }
                    Scene.SOUND -> {
                        SimSlider("媒体音量", state.value, "volume", click = onEvent)
                        SimSlider("屏幕亮度", state.brightness, "brightness", click = onEvent)
                        Box(Modifier.fillMaxWidth().height(100.dp).background(Color.White.copy(alpha = .1f + state.brightness / 120f), RoundedCornerShape(16.dp)).border(1.dp, Muted, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                            Text("屏幕亮度预览", style = MaterialTheme.typography.bodySmall, color = Color.Black.copy(alpha = .3f + state.brightness / 150f))
                        }
                    }
                    Scene.FONT -> {
                        Text("平安喜乐，天天好心情", fontSize = state.value.coerceIn(20f, 36f).sp, lineHeight = (state.value * 1.5f).sp, modifier = Modifier.fillMaxWidth().padding(12.dp).testTag("font_preview"))
                        SimSlider("预览字号", state.value, "font_slider", 20f..36f, onEvent)
                        SimButton("应用字号", "apply_font", onEvent)
                        Notice("这里只调整示例文字；首页“字号”可以调整课堂字号。")
                    }
                    Scene.CARE -> {
                        SimSwitch("手机简易模式", state.enabled, click = onEvent)
                        Surface(color = Color(0xFFE9F0FE), shape = RoundedCornerShape(16.dp)) {
                            Text(if (state.enabled) "☎ 电话\n▧ 相册" else "电话  相册  设置", Modifier.padding(if (state.enabled) 22.dp else 12.dp), fontSize = if (state.enabled) 28.sp else 20.sp)
                        }
                        SimSwitch("软件关怀模式", state.secondary, "care_toggle", onEvent)
                        Text("邻里生活：今日天气晴", fontSize = if (state.secondary) 28.sp else 20.sp, lineHeight = 42.sp)
                        Notice("手机和软件各有自己的开关。不同机型的名称与入口会有差异。")
                    }
                    Scene.INPUT -> {
                        SimInput("试着写一句话", state, onEvent)
                        SimButton("清空重写", "clear", onEvent)
                        SimButton("写好了", "finish_input", onEvent)
                    }
                    Scene.SEARCH -> {
                        SimInput("搜索，例如：相册", state, onEvent)
                        SimButton("搜索", "search", onEvent)
                        if (state.page == "results") {
                            if (state.secondary) SimButton("家庭相册  ›", "search_result", onEvent) else Notice("没有找到，换个关键词再试试。")
                        }
                        if (state.page == "album") PhotoArt(Modifier.fillMaxWidth().height(180.dp))
                    }
                    Scene.CHAT -> {
                        Notice("家人：今天过得好吗？")
                        state.messages.forEach { message -> Surface(color = Color(0xFFE6F3EB), shape = RoundedCornerShape(16.dp)) { Text(message, Modifier.fillMaxWidth().padding(14.dp), style = MaterialTheme.typography.bodyMedium) } }
                        SimInput("写一句问候", state, onEvent)
                        SimButton("发送", "send", onEvent)
                    }
                    Scene.PHOTO -> {
                        if (state.page != "photo") {
                            PhotoArt(Modifier.fillMaxWidth().height(160.dp).target("photo_thumb", actualFocus).clickable { onEvent(PracticeEvent.Click("open_photo")) })
                            SimButton("打开“山间小屋”", "open_photo", onEvent)
                        } else {
                            var pan by remember { mutableStateOf(Offset.Zero) }
                            Box(Modifier.fillMaxWidth().height(280.dp).clip(RoundedCornerShape(18.dp)).background(Paper).testTag("sim_photo")
                                .pointerInput(Unit) { detectTransformGestures { _, delta, zoom, _ -> pan += delta; onEvent(PracticeEvent.Gesture("zoom", zoom)) } }
                                .pointerInput(state.zoom) { detectTapGestures(onDoubleTap = { onEvent(PracticeEvent.Gesture("zoom", if (state.zoom > 1.2f) .5f else 2f)) }) }) {
                                PhotoArt(Modifier.fillMaxSize().graphicsLayer { scaleX = state.zoom; scaleY = state.zoom; translationX = pan.x.coerceIn(-160f, 160f); translationY = pan.y.coerceIn(-160f, 160f) })
                            }
                            Text("放大倍数：${"%.1f".format(java.util.Locale.ROOT, state.zoom)}", style = MaterialTheme.typography.bodySmall)
                            SimButton("‹ 返回相册", "photo_back", onEvent)
                        }
                    }
                    Scene.SEND_PHOTO -> when (state.page) {
                        "attachments" -> { Notice("添加内容"); SimButton("相册  ›", "album", onEvent); SimButton("取消", "back", onEvent) }
                        "picker" -> {
                            Text("选一张照片", style = MaterialTheme.typography.bodyMedium)
                            (0..2).forEach { index ->
                                Column(Modifier.fillMaxWidth().target("photo_$index", actualFocus).clip(RoundedCornerShape(16.dp)).clickable { onEvent(PracticeEvent.Click("photo_$index")) }.padding(8.dp)) {
                                    PhotoArt(Modifier.fillMaxWidth().height(110.dp), index)
                                    Text("${listOf("山间小屋", "花园", "海边")[index]}  ${if (state.selected == index) "✓ 已选中" else "○ 未选择"}", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            SimButton("发送照片", "send_photo", onEvent)
                        }
                        else -> {
                            Notice("家人：给我看看今天的照片吧。")
                            if (state.secondary) { PhotoArt(Modifier.fillMaxWidth().height(160.dp), state.selected ?: 0); Notice("你发送的照片") }
                            SimButton("＋ 添加", "add_photo", onEvent)
                        }
                    }
                    Scene.SCAN -> when (state.page) {
                        "main", "menu" -> {
                            MoreButton("＋ 更多", onEvent)
                            if (state.page == "menu") SimButton("扫一扫", "scan", onEvent)
                            Notice("本课使用示例二维码。")
                        }
                        "scanner" -> { QrArt(Modifier.fillMaxWidth().height(200.dp)); SimButton("对准示例二维码", "scan_code", onEvent) }
                        else -> Notice("扫码结果\n欢迎来到社区图书角。\n这是一段示例文字。")
                    }
                    Scene.INSTALL -> {
                        AppTile("每日天气", "weather", onClick = {})
                        Notice("发布者：课堂示例\n安装状态：${if (state.installed) "已安装" else "未安装"}")
                        if (state.installed) SimButton("卸载", "uninstall", onEvent) else SimButton("安装", "install", onEvent)
                    }
                }
                if (diagram && state.dialog != null) Notice(when (state.dialog) {
                    "permission" -> "允许使用相机吗？\n［拒绝］     ［允许］"
                    "reset" -> "要恢复默认设置吗？\n［取消］     ［确定］"
                    "long" -> "长按菜单\n移动图标   查看详情   取消"
                    else -> "卸载会移除软件及可能存在的本机数据。\n［取消］     ［确认卸载］"
                })
            }
        }
        if (state.dialog != null && !diagram) {
            val permission = state.dialog == "permission"
            val longMenu = state.dialog == "long"
            AlertDialog(onDismissRequest = { onEvent(PracticeEvent.Click("dismiss")) }, title = { Text(if (permission) "允许使用相机吗？" else if (longMenu) "相册的更多操作" else if (state.dialog == "reset") "恢复默认设置？" else "确认卸载？") }, text = {
                Text(if (permission) "“安心生活”想使用相机完成扫码。这里只模拟权限，不会使用真实相机。" else if (longMenu) "长按可以打开更多操作。这里可以查看详情、移动图标，或取消返回。" else if (state.dialog == "reset") "恢复默认后，阅读提醒会关闭。可以先取消，保留当前状态。" else "真实卸载可能移除软件的本机数据。本课只卸载示例软件。", modifier = Modifier.verticalScroll(rememberScrollState()), style = MaterialTheme.typography.bodyMedium)
            }, confirmButton = {
                TextButton(onClick = { onEvent(PracticeEvent.Click(if (permission) "allow" else if (longMenu) "dismiss" else "confirm")) }, modifier = Modifier.heightIn(min = 56.dp).testTag(if (permission) "sim_allow" else "sim_confirm")) { Text(if (permission) "允许" else if (longMenu) "知道了" else "确定") }
            }, dismissButton = {
                if (!longMenu) TextButton(onClick = { onEvent(PracticeEvent.Click(if (permission) "deny" else "cancel")) }, modifier = Modifier.heightIn(min = 56.dp).testTag(if (permission) "sim_deny" else "sim_cancel")) { Text(if (permission) "拒绝" else "取消") }
            })
        }
    }
}

@Composable
private fun AppTile(title: String, tag: String, onClick: () -> Unit, onLong: (() -> Unit)? = null) {
    Column(Modifier.fillMaxWidth().target(tag, LocalTarget.current).clip(RoundedCornerShape(18.dp)).combinedClickable(onClick = onClick, onLongClick = onLong, onLongClickLabel = if (onLong != null) "按住查看更多" else null).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.sizeIn(minWidth = 72.dp, minHeight = 72.dp).background(Color(0xFFDDECDD), RoundedCornerShape(22.dp)).padding(8.dp), contentAlignment = Alignment.Center) { Text(if (title == "相册") "▧" else "☀", color = Green, fontSize = 38.sp, lineHeight = 48.sp) }
        Text(title, style = MaterialTheme.typography.bodyLarge)
    }
}
