# 手机小课堂

面向家中长辈的离线安卓入门课堂。参考华为 HarmonyOS 4.x 的设置风格，用图解解释概念，再用本地模拟页面练习。

成品位于 `deliverables/`：调试签名 APK、完整源码压缩包、首页截图及 SHA-256 校验值。验收情况见 [VALIDATION.md](VALIDATION.md)。

## 使用

打开 App，选择课程。每课依次为 **三张图解 → 跟练 → 自己试试 → 完成回顾**，也可以直接进入独立练习。点错后可修改、请求提示或重新开始。首页提供字号设置，并显示本机学习进度。

包含 22 课：

- 基础操作：点按/长按、上下滑动、左右翻页、返回/桌面、更多/设置、开关/弹窗。
- 网络与设置：WLAN、移动数据、套餐限额、单个应用联网、权限、通知、音量/亮度、字体、简易/关怀模式。
- 日常软件：输入/删除、搜索、发文字、查看/放大照片、选图发送、扫一扫、安装/卸载。

WLAN 练习密码为 `12345678`；流量课程使用 2GB 套餐及 0.3GB 模拟下载。权限课程需要先体验拒绝，再到模拟设置允许，以理解两种结果。

## 构建

- JDK 21（Java/Kotlin 字节码目标为 17）
- Android SDK Platform 36、Build Tools；最低运行版本 Android 8.0 / API 26
- Gradle Wrapper 9.3.1、AGP 8.13.2、Kotlin 2.3.10

在 `local.properties` 配置本机 `sdk.dir`，或使用 `ANDROID_HOME`。首次构建需要联网获取构建依赖，安装后的 App 完全离线。

```powershell
.\gradlew.bat :app:assembleDebug
.\gradlew.bat :app:testDebugUnitTest :app:lintDebug
.\gradlew.bat :app:connectedDebugAndroidTest
```

APK：`app/build/outputs/apk/debug/app-debug.apk`。这是供家庭试用的调试签名安装包；公开上架需配置自己的发布签名。

## 代码组织

- `learning/Lessons.kt`：22 课、66 张图解的文案及学习目标。
- `learning/PracticeEngine.kt`：纯 Kotlin 操作事件、模拟状态和完成判断，不接触系统能力。
- `learning/ClassroomModel.kt`：页面状态、跟练到独立练习、重练与进度写入。
- `learning/ProgressRepository.kt`：DataStore 保存课程完成情况、最近位置及字号。
- `ui/ClassroomApp.kt`：首页、图解、练习、完成回顾。
- `ui/Scenes.kt`、`ui/Illustrations.kt`：模拟控件和本地矢量插图。图解与练习复用同一套控件。

新增课程时需要同时定义讲解和目标、实现对应状态转换与场景 UI，并添加可完成的操作旅程测试。

## 练习边界

所有网络、权限、相机、扫码、软件安装和消息发送均为本地模拟。示例照片使用 Canvas 绘制，不读取真实相册；输入使用系统键盘，文字只存放在本次练习的内存状态。Manifest 不声明网络、相机、存储、通讯录或定位权限，也不包含统计或广告 SDK。

重新开始会清空当前模拟状态，保留已学课程。重新打开 App 后，在首页点继续学习可回到最近讲解页或练习阶段；练习阶段从初始状态重做。手机的系统返回退出练习到图解，模拟导航栏专门用于学习返回和桌面。

华为不同型号的菜单可能不同；本项目提供教学示意，不逐型号还原。较新的原生鸿蒙设备需要单独评估安装兼容性。
