package com.example.phoneclass

import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.lifecycle.Lifecycle
import com.example.phoneclass.learning.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

class ClassroomInteractionTest {
    @get:Rule val rule = createAndroidComposeRule<MainActivity>()
    private fun open(scene: Scene, stage: Stage = Stage.SOLO) {
        rule.waitUntil(10000) { rule.activity.model.state.value.loaded }
        rule.runOnIdle { rule.activity.model.open(scene.name); rule.activity.model.start(stage) }
    }
    private fun tap(tag: String) { rule.onNodeWithTag("sim_$tag").performScrollTo().performClick() }
    private fun input(value: String) {
        rule.onNodeWithTag("sim_text_input").performScrollTo().performTextReplacement(value)
        rule.onNodeWithTag("sim_text_input").performImeAction()
        rule.waitForIdle()
    }
    private fun done() {
        rule.runOnIdle { assertEquals("Unexpected practice state: ${rule.activity.model.state.value}", Stage.DONE, rule.activity.model.state.value.stage) }
        rule.onNodeWithTag("lesson_complete").assertExists()
    }
    @Test fun wifiIncorrectPasswordThenSuccessfulConnection() {
        open(Scene.WIFI); tap("toggle"); tap("network"); input("00000000"); tap("connect")
        rule.onNodeWithTag("feedback").assertTextContains("密码不匹配", substring = true)
        rule.onNodeWithTag("lesson_complete").assertDoesNotExist()
        input("12345678"); tap("connect"); done()
    }
    @Test fun cameraDenialAndRecovery() {
        open(Scene.PERMISSION); tap("open_scan")
        rule.onNodeWithTag("sim_deny").performClick()
        tap("open_scan")
        rule.onNodeWithTag("feedback").assertTextContains("不可用", substring = true)
        tap("permission_settings"); tap("allow"); tap("open_scan"); done()
    }
    @Test fun budgetStopsAtLimit() {
        open(Scene.BUDGET); tap("budget_2"); tap("toggle"); tap("download"); done()
        rule.runOnIdle { assertEquals(2.1f, rule.activity.model.state.value.practice.used, .001f) }
    }
    @Test fun appRestrictionBlocksMobileAndAllowsWifi() {
        open(Scene.APP_NETWORK); tap("toggle"); tap("test_mobile")
        rule.onNodeWithTag("feedback").assertTextContains("访问被阻止", substring = true)
        tap("test_wifi"); done()
    }
    @Test fun fontPreviewAndGuidedToIndependentReset() {
        open(Scene.FONT, Stage.GUIDED)
        rule.onNodeWithTag("sim_font_slider").performScrollTo().performSemanticsAction(SemanticsActions.SetProgress) { it(32f) }
        rule.onNodeWithTag("font_preview").assertTextEquals("平安喜乐，天天好心情")
        tap("apply_font")
        rule.onNodeWithTag("guided_done").performScrollTo().performClick()
        rule.runOnIdle { assertEquals(Stage.SOLO, rule.activity.model.state.value.stage); assertEquals(22f, rule.activity.model.state.value.practice.value) }
        rule.onNodeWithTag("sim_font_slider").performScrollTo().performSemanticsAction(SemanticsActions.SetProgress) { it(34f) }
        tap("apply_font"); done()
    }
    @Test fun selectAndSendPhoto() {
        open(Scene.SEND_PHOTO); tap("add_photo"); tap("album"); tap("photo_1")
        rule.onNodeWithTag("lesson_complete").assertDoesNotExist()
        tap("send_photo"); done()
        rule.runOnIdle { assertEquals(1, rule.activity.model.state.value.practice.selected) }
    }
    @Test fun restartRestoresInitialScene() {
        open(Scene.WIFI); tap("toggle"); tap("network"); input("123")
        rule.onNodeWithTag("restart").performClick()
        rule.runOnIdle {
            val s = rule.activity.model.state.value.practice
            assertEquals("", s.text); assertFalse(s.enabled); assertTrue(s.achieved.isEmpty())
        }
    }
    @Test fun backgroundAndReturnRetainsCurrentPractice() {
        open(Scene.WIFI); tap("toggle"); tap("network"); input("123")
        rule.activityRule.scenario.moveToState(Lifecycle.State.CREATED)
        rule.activityRule.scenario.moveToState(Lifecycle.State.RESUMED)
        rule.onNodeWithTag("sim_text_input").assertTextContains("123")
        rule.runOnIdle { assertEquals("password", rule.activity.model.state.value.practice.page) }
    }
    @Test fun all22LessonsAnd66PicturesRender() {
        rule.waitUntil(10000) { rule.activity.model.state.value.loaded }
        Lessons.all.forEach { lesson ->
            rule.runOnIdle { rule.activity.model.open(lesson.id) }
            (0..2).forEach { index ->
                rule.onNodeWithText(lesson.panels[index].title).assertExists()
                if (lesson.scene == Scene.WIFI && index == 0) captureAcceptance("wifi-illustration")
                if (index < 2) rule.onNodeWithTag("next_panel").performClick()
            }
            rule.onNodeWithTag("start_guided").performClick()
            rule.onNodeWithText("练习页面").assertExists()
        }
    }
    @Test fun realTouchGesturesDrivePractice() {
        open(Scene.TAP)
        tap("album"); tap("back")
        rule.onNodeWithTag("sim_album").performScrollTo().performTouchInput { longClick() }
        done()
        open(Scene.VERTICAL)
        rule.onNodeWithTag("sim_scroll_list").performScrollTo().performTouchInput { swipeUp(durationMillis = 800) }
        rule.onNodeWithTag("sim_family_album").performScrollTo().performClick()
        done()
        open(Scene.HORIZONTAL)
        repeat(2) { rule.onNodeWithTag("sim_pager").performScrollTo().performTouchInput { swipeLeft(durationMillis = 600) } }
        done()
        open(Scene.PHOTO)
        tap("open_photo")
        rule.onNodeWithTag("sim_photo").performScrollTo().performTouchInput { doubleClick() }
        tap("photo_back"); done()
    }
    @Test fun progressAndFontAreSavedAndResumeResetsOnlySimulation() {
        rule.waitUntil(10000) { rule.activity.model.state.value.loaded }
        rule.runOnIdle { rule.activity.model.open("WIFI"); rule.activity.model.panel(1); rule.activity.model.font(1) }
        rule.waitUntil(10000) { rule.activity.model.state.value.progress.recent == "WIFI" && rule.activity.model.state.value.progress.panel == 1 && rule.activity.model.state.value.progress.fontLevel == 1 }
        rule.activityRule.scenario.recreate()
        rule.waitUntil(10000) { rule.activity.model.state.value.loaded }
        rule.runOnIdle { rule.activity.model.home(); rule.activity.model.open("WIFI", resume = true) }
        rule.runOnIdle { assertEquals(1, rule.activity.model.state.value.panel); assertEquals(1, rule.activity.model.state.value.progress.fontLevel); assertFalse(rule.activity.model.state.value.practice.connected) }
        rule.runOnIdle { rule.activity.model.font(0) }
    }
}
