package com.example.phoneclass.learning

import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.Parameterized

fun click(target: String) = PracticeEvent.Click(target)
fun input(value: String) = PracticeEvent.Input(value)
fun gesture(kind: String, amount: Float = 1f) = PracticeEvent.Gesture(kind, amount)
fun adjust(target: String, value: Float) = PracticeEvent.Adjust(target, value)

/** These are the learner's actual operations, independent of UI screen coordinates. */
fun successfulJourney(scene: Scene): List<PracticeEvent> = when (scene) {
    Scene.TAP -> listOf(click("album"), click("back"), gesture("long"))
    Scene.VERTICAL -> listOf(gesture("scroll"), click("family_album"))
    Scene.HORIZONTAL -> listOf(gesture("left"), gesture("left"))
    Scene.NAVIGATION -> listOf(click("album"), click("open_photo"), click("nav_back"), click("nav_home"))
    Scene.MENU -> listOf(click("more"), click("settings"), click("font_entry"))
    Scene.SWITCH -> listOf(click("toggle"), click("reset_dialog"), click("cancel"))
    Scene.WIFI -> listOf(click("toggle"), click("network"), input("12345678"), click("connect"))
    Scene.DATA -> listOf(click("toggle"), click("try_network"), click("wifi_toggle"), click("try_network"))
    Scene.BUDGET -> listOf(click("budget_2"), click("toggle"), click("download"))
    Scene.APP_NETWORK -> listOf(click("toggle"), click("test_mobile"), click("test_wifi"))
    Scene.PERMISSION -> listOf(click("open_scan"), click("deny"), click("permission_settings"), click("allow"), click("open_scan"))
    Scene.NOTIFICATION -> listOf(click("toggle"), click("notify"), click("toggle"), click("notify"))
    Scene.SOUND -> listOf(adjust("volume", 70f), adjust("brightness", 80f))
    Scene.FONT -> listOf(adjust("font_slider", 32f), click("apply_font"))
    Scene.CARE -> listOf(click("toggle"), click("care_toggle"))
    Scene.INPUT -> listOf(input("写错了"), click("clear"), input("今天很好"), click("finish_input"))
    Scene.SEARCH -> listOf(input("相册"), click("search"), click("search_result"))
    Scene.CHAT -> listOf(input("今天很好，放心吧"), click("send"))
    Scene.PHOTO -> listOf(click("open_photo"), gesture("zoom", 2f), click("photo_back"))
    Scene.SEND_PHOTO -> listOf(click("add_photo"), click("album"), click("photo_1"), click("send_photo"))
    Scene.SCAN -> listOf(click("more"), click("scan"), click("allow"), click("scan_code"))
    Scene.INSTALL -> listOf(click("install"), click("uninstall"), click("confirm"))
}

@RunWith(Parameterized::class)
class LessonJourneyTest(private val scene: Scene) {
    companion object { @JvmStatic @Parameterized.Parameters(name = "{0}") fun scenes() = Scene.entries.map { arrayOf(it) } }
    @Test fun lessonCanBeCompletedThroughItsOperations() {
        val lesson = Lessons.get(scene.name)
        var state = PracticeEngine.initial(scene)
        assertFalse("An untouched scene must not pass", PracticeEngine.complete(lesson, state))
        val journey = successfulJourney(scene)
        journey.forEachIndexed { index, event ->
            state = PracticeEngine.reduce(scene, state, event)
            if (index < journey.lastIndex) assertFalse("Must perform the last operation too", PracticeEngine.complete(lesson, state))
        }
        assertTrue("All learning goals should be reachable: $scene", PracticeEngine.complete(lesson, state))
    }
    @Test fun restartingClearsTransientPractice() {
        val finalState = successfulJourney(scene).fold(PracticeEngine.initial(scene)) { s, e -> PracticeEngine.reduce(scene, s, e) }
        assertTrue(PracticeEngine.complete(Lessons.get(scene.name), finalState))
        val restarted = PracticeEngine.initial(scene)
        assertTrue(restarted.achieved.isEmpty())
        assertTrue(restarted.messages.isEmpty())
        assertEquals("", restarted.text)
        assertFalse(restarted.connected)
        assertFalse(PracticeEngine.complete(Lessons.get(scene.name), restarted))
    }
}

class PracticeEngineTest {
    private fun run(scene: Scene, vararg events: PracticeEvent) = events.fold(PracticeEngine.initial(scene)) { s, e -> PracticeEngine.reduce(scene, s, e) }
    @Test fun catalogueContains22CompleteUniqueLessons() {
        assertEquals(22, Lessons.all.size)
        assertEquals(22, Lessons.all.map { it.id }.toSet().size)
        assertEquals(listOf(6, 9, 7), Lessons.all.groupBy { it.category }.values.map { it.size })
        Lessons.all.forEach { lesson ->
            assertEquals(3, lesson.panels.size)
            assertTrue(lesson.panels.all { it.title.isNotBlank() && it.body.length > 15 && it.caption.isNotBlank() })
            assertEquals(lesson.goals.size, lesson.goals.map { it.key }.toSet().size)
        }
    }
    @Test fun wifiWrongPasswordCanBeCorrected() {
        var state = run(Scene.WIFI, click("toggle"), click("network"), input("wrong"), click("connect"))
        assertFalse(state.connected); assertTrue(state.feedback.contains("密码不匹配")); assertEquals("password", state.page)
        state = PracticeEngine.reduce(Scene.WIFI, state, input("12345678"))
        state = PracticeEngine.reduce(Scene.WIFI, state, click("connect"))
        assertTrue(state.connected); assertEquals("", state.text)
        state = PracticeEngine.reduce(Scene.WIFI, state, click("toggle"))
        assertFalse(state.connected); assertFalse(PracticeEngine.complete(Lessons.get("WIFI"), state))
    }
    @Test fun cannotConnectWithWifiDisabled() {
        val s = run(Scene.WIFI, click("network"), input("12345678"), click("connect"))
        assertFalse(s.connected); assertFalse(s.achieved.contains("connected"))
    }
    @Test fun deniedCameraBlocksScanUntilAllowed() {
        var s = run(Scene.PERMISSION, click("open_scan"), click("deny"), click("open_scan"))
        assertEquals(false, s.permission); assertNotEquals("scanning", s.page); assertTrue(s.feedback.contains("不可用"))
        s = PracticeEngine.reduce(Scene.PERMISSION, s, click("permission_settings"))
        s = PracticeEngine.reduce(Scene.PERMISSION, s, click("allow"))
        s = PracticeEngine.reduce(Scene.PERMISSION, s, click("open_scan"))
        assertEquals("scanning", s.page); assertTrue(PracticeEngine.complete(Lessons.get("PERMISSION"), s))
    }
    @Test fun choosingAllowFirstCanStillBeCorrectedInSettings() {
        var s = run(Scene.PERMISSION, click("open_scan"), click("allow"), click("permission_settings"), click("deny"), click("allow"), click("open_scan"))
        assertTrue(PracticeEngine.complete(Lessons.get("PERMISSION"), s))
    }
    @Test fun dataRestrictionDoesNotDisableWifi() {
        val s = run(Scene.APP_NETWORK, click("toggle"), click("test_mobile"), click("test_wifi"))
        assertFalse(s.enabled); assertTrue(s.secondary)
        assertTrue(s.achieved.containsAll(setOf("mobile_blocked", "wifi_ok")))
    }
    @Test fun limitRequiresBothBudgetAndStopSwitch() {
        val s = run(Scene.BUDGET, click("budget_2"), click("download"))
        assertEquals(2.1f, s.used, .001f); assertFalse(s.achieved.contains("blocked"))
        val limited = run(Scene.BUDGET, click("budget_2"), click("toggle"), click("download"), click("download"))
        assertEquals(2.1f, limited.used, .001f); assertTrue(limited.feedback.contains("停止"))
    }
    @Test fun textIsADraftUntilSendAndEmptyCannotSend() {
        val empty = run(Scene.CHAT, click("send")); assertTrue(empty.messages.isEmpty())
        val draft = run(Scene.CHAT, input("平安到家")); assertTrue(draft.messages.isEmpty())
        val sent = PracticeEngine.reduce(Scene.CHAT, draft, click("send"))
        assertEquals(listOf("平安到家"), sent.messages); assertEquals("", sent.text)
    }
    @Test fun photoSelectionIsNotSending() {
        val s = run(Scene.SEND_PHOTO, click("add_photo"), click("album"), click("send_photo"))
        assertFalse(s.secondary); assertFalse(PracticeEngine.complete(Lessons.get("SEND_PHOTO"), s))
        val selected = PracticeEngine.reduce(Scene.SEND_PHOTO, s, click("photo_2"))
        assertEquals(2, selected.selected); assertFalse(selected.secondary)
        val sent = PracticeEngine.reduce(Scene.SEND_PHOTO, selected, click("send_photo"))
        assertTrue(sent.secondary); assertEquals(2, sent.selected)
    }
    @Test fun cancellingUninstallRetainsApp() {
        val s = run(Scene.INSTALL, click("install"), click("uninstall"), click("cancel"))
        assertTrue(s.installed); assertNull(s.dialog)
        assertFalse(PracticeEngine.complete(Lessons.get("INSTALL"), s))
    }
    @Test fun wrongSearchCanBeRetried() {
        var s = run(Scene.SEARCH, input("不存在"), click("search"), click("search_result"))
        assertFalse(s.secondary); assertEquals("results", s.page)
        s = PracticeEngine.reduce(Scene.SEARCH, s, input("相册"))
        s = PracticeEngine.reduce(Scene.SEARCH, s, click("search"))
        s = PracticeEngine.reduce(Scene.SEARCH, s, click("search_result"))
        assertEquals("album", s.page)
    }
    @Test fun pastMilestonesDoNotOverrideCurrentState() {
        val sound = run(Scene.SOUND, adjust("volume", 80f), adjust("volume", 20f), adjust("brightness", 80f))
        assertFalse(PracticeEngine.complete(Lessons.get("SOUND"), sound))
        val notification = run(Scene.NOTIFICATION, click("notify"), click("toggle"), click("notify"))
        assertFalse(PracticeEngine.complete(Lessons.get("NOTIFICATION"), notification))
        val permission = run(Scene.PERMISSION, click("open_scan"), click("allow"), click("open_scan"), click("permission_settings"), click("deny"), click("allow"))
        assertFalse(PracticeEngine.complete(Lessons.get("PERMISSION"), permission))
    }
}
