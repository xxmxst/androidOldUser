package com.example.phoneclass.learning

data class PracticeState(
    val page: String = "main", val enabled: Boolean = false, val secondary: Boolean = false,
    val permission: Boolean? = null, val text: String = "", val value: Float = 30f,
    val brightness: Float = 30f, val budget: Int = 0, val used: Float = 1.8f,
    val index: Int = 0, val selected: Int? = null, val zoom: Float = 1f,
    val connected: Boolean = false, val installed: Boolean = false,
    val messages: List<String> = emptyList(), val achieved: Set<String> = emptySet(),
    val feedback: String = "", val dialog: String? = null
)
sealed interface PracticeEvent {
    data class Click(val target: String) : PracticeEvent
    data class Input(val text: String) : PracticeEvent
    data class Adjust(val target: String, val value: Float) : PracticeEvent
    data class Gesture(val kind: String, val amount: Float = 1f) : PracticeEvent
}

/** Pure reducer: never reads settings, network, camera, gallery, or contacts. */
object PracticeEngine {
    fun initial(scene: Scene) = PracticeState(enabled = scene in setOf(Scene.APP_NETWORK, Scene.NOTIFICATION), secondary = scene == Scene.APP_NETWORK, value = if (scene == Scene.FONT) 22f else 30f)
    fun complete(lesson: Lesson, s: PracticeState): Boolean {
        if (!lesson.goals.all { it.key in s.achieved }) return false
        return when (lesson.scene) {
            Scene.WIFI -> s.connected && s.enabled
            Scene.BUDGET -> s.budget == 2 && s.enabled && s.used > 2
            Scene.APP_NETWORK -> !s.enabled && s.secondary
            Scene.PERMISSION, Scene.SCAN -> s.permission == true
            Scene.NOTIFICATION -> s.enabled && s.secondary
            Scene.SOUND -> s.value >= 60 && s.brightness >= 60
            Scene.SWITCH -> s.enabled && s.dialog == null
            Scene.DATA -> s.secondary
            Scene.FONT -> s.value >= 28
            Scene.CARE -> s.enabled && s.secondary
            Scene.INSTALL -> !s.installed
            else -> true
        }
    }
    fun nextGoal(lesson: Lesson, s: PracticeState) = lesson.goals.firstOrNull { it.key !in s.achieved }
    fun reduce(scene: Scene, state: PracticeState, event: PracticeEvent): PracticeState {
        var s = state.copy(feedback = "")
        fun mark(key: String) { s = s.copy(achieved = s.achieved + key) }
        fun say(message: String) { s = s.copy(feedback = message) }
        if (event is PracticeEvent.Input) {
            s = s.copy(text = event.text.take(120))
            if (scene == Scene.INPUT) {
                if (s.text.isNotBlank()) mark("typed")
                if (state.text.isNotEmpty() && s.text.length < state.text.length) mark("deleted")
            }
            if (scene == Scene.CHAT && s.text.isNotBlank()) mark("draft")
            return s
        }
        if (event is PracticeEvent.Adjust) {
            when (event.target) {
                "volume" -> { s = s.copy(value = event.value.coerceIn(0f, 100f)); if (s.value >= 60) mark("volume") }
                "brightness" -> { s = s.copy(brightness = event.value.coerceIn(0f, 100f)); if (s.brightness >= 60) mark("brightness") }
                "font_slider" -> { s = s.copy(value = event.value.coerceIn(20f, 36f)); if (s.value >= 28) mark("font_changed") }
            }
            return s
        }
        if (event is PracticeEvent.Gesture) {
            when (scene) {
                Scene.TAP -> if (event.kind == "long" && s.page == "main") { mark("long"); s = s.copy(dialog = "long"); say("长按打开了更多操作。") }
                Scene.VERTICAL -> if (event.kind == "scroll") mark("scroll")
                Scene.HORIZONTAL -> {
                    s = s.copy(index = (s.index + if (event.kind == "left") 1 else -1).coerceIn(0, 2))
                    if (event.kind == "left") mark("swipe")
                    if (s.index == 2) mark("third")
                }
                Scene.PHOTO -> if (s.page == "photo") {
                    s = s.copy(zoom = (s.zoom * event.amount).coerceIn(1f, 3f))
                    if (s.zoom > 1.2f) mark("zoomed")
                }
                else -> Unit
            }
            return s
        }
        val target = (event as PracticeEvent.Click).target
        if (target == "dismiss") return s.copy(dialog = null)
        when (scene) {
            Scene.TAP -> when (target) {
                "album" -> { mark("tap"); s = s.copy(page = "album"); say("点一下，打开了相册。") }
                "back" -> s = s.copy(page = "main")
            }
            Scene.VERTICAL -> if (target == "family_album") { mark("found"); say("找到了！上下滑动可以看见屏幕外的内容。") }
            Scene.HORIZONTAL -> Unit
            Scene.NAVIGATION -> when (target) {
                "album" -> s = s.copy(page = "album")
                "open_photo" -> { s = s.copy(page = "photo"); mark("opened") }
                "nav_back" -> {
                    if (s.page == "photo") { mark("back"); s = s.copy(page = "album") }
                    else s = s.copy(page = "main")
                }
                "nav_home" -> { if ("back" in s.achieved) mark("home"); s = s.copy(page = "main") }
            }
            Scene.MENU -> when (target) {
                "more" -> { mark("menu"); s = s.copy(page = "menu") }
                "settings" -> if (s.page == "menu") { mark("settings"); s = s.copy(page = "settings") }
                "font_entry" -> if (s.page == "settings") { mark("font"); s = s.copy(page = "font"); say("找到了字体大小！") }
                "back" -> s = s.copy(page = "main")
            }
            Scene.SWITCH -> when (target) {
                "toggle" -> { s = s.copy(enabled = !s.enabled); if (s.enabled) mark("on") }
                "reset_dialog" -> { mark("dialog"); s = s.copy(dialog = "reset") }
                "cancel" -> { if (s.dialog == "reset" && s.enabled) mark("cancel"); s = s.copy(dialog = null); say("已取消。开关保持原来的状态。") }
                "confirm" -> s = s.copy(enabled = false, dialog = null, achieved = emptySet(), feedback = "已恢复默认。重新打开开关，再试着取消一次。")
            }
            Scene.WIFI -> when (target) {
                "toggle" -> { s = s.copy(enabled = !s.enabled, connected = false, page = "main", text = ""); if (s.enabled) mark("wifi_on") }
                "network" -> if (s.enabled) { mark("network"); s = s.copy(page = "password") } else say("先打开 WLAN，才能选择网络。")
                "connect" -> if (s.enabled && s.page == "password") {
                    if (s.text == "12345678") { mark("connected"); s = s.copy(connected = true, page = "main", text = ""); say("温暖的家：已连接。") }
                    else say("密码不匹配。练习密码是 12345678，请修改后重试。")
                }
                "cancel" -> s = s.copy(page = "main", text = "")
            }
            Scene.DATA -> when (target) {
                "toggle" -> s = s.copy(enabled = !s.enabled)
                "wifi_toggle" -> s = s.copy(secondary = !s.secondary)
                "try_network" -> when {
                    s.secondary -> { mark("wifi"); say("当前通过家里的 Wi-Fi 上网。") }
                    s.enabled -> { mark("mobile"); say("当前使用手机卡的移动数据，会消耗套餐流量。") }
                    else -> say("两种连接都关闭了，所以现在无法上网。")
                }
            }
            Scene.BUDGET -> when (target) {
                "budget_2" -> { s = s.copy(budget = 2); mark("budget") }
                "budget_5" -> { s = s.copy(budget = 5); say("已选择 5GB；本课练习目标是 2GB。") }
                "toggle" -> { s = s.copy(enabled = !s.enabled); if (s.enabled) mark("stop") }
                "download" -> {
                    if (s.enabled && s.budget > 0 && s.used > s.budget) say("移动数据已停止。可以重新开始本次练习。")
                    else {
                        s = s.copy(used = s.used + .3f)
                        if (s.enabled && s.budget == 2 && s.used > 2) { mark("blocked"); say("用量达到 2.1GB，超过 2GB：模拟移动数据已停止。") }
                        else say("模拟下载完成。观察当前用量，再检查限额和停止开关。")
                    }
                }
            }
            Scene.APP_NETWORK -> when (target) {
                "toggle" -> { s = s.copy(enabled = !s.enabled); if (!s.enabled) mark("restricted") }
                "wifi_toggle" -> s = s.copy(secondary = !s.secondary)
                "test_mobile" -> if (!s.enabled) { mark("mobile_blocked"); say("访问被阻止：乐看视频不允许使用移动数据。") } else say("视频能使用移动数据，会消耗套餐。试着关闭它的移动数据。")
                "test_wifi" -> if (s.secondary) { mark("wifi_ok"); say("通过 WLAN 可以访问；移动数据限制不影响这条连接。") } else say("WLAN 也被关闭了。请保留 WLAN 后重试。")
            }
            Scene.PERMISSION -> when (target) {
                "open_scan" -> when (s.permission) {
                    null -> s = s.copy(dialog = "permission")
                    false -> say("相机未允许，模拟扫码不可用。可以到权限设置修改。")
                    true -> { mark("scanned"); s = s.copy(page = "scanning"); say("相机已允许，现在可以模拟扫码。") }
                }
                "deny" -> { mark("denied"); s = s.copy(permission = false, dialog = null, achieved = s.achieved - "scanned"); say("已拒绝相机权限，模拟扫码暂不可用。") }
                "permission_settings" -> s = s.copy(page = "permissions")
                "allow" -> { mark("allowed"); s = s.copy(permission = true, dialog = null, page = "main"); say("已允许相机。现在重新打开模拟扫码。") }
                "back" -> s = s.copy(page = "main")
            }
            Scene.NOTIFICATION -> when (target) {
                "toggle" -> s = s.copy(enabled = !s.enabled)
                "notify" -> if (s.enabled) { mark("notified"); s = s.copy(secondary = true); say("新通知：社区活动明天开始。") } else { mark("silent"); s = s.copy(secondary = false); say("消息到达了，但通知已关闭，所以没有提醒卡片。") }
            }
            Scene.SOUND -> Unit
            Scene.FONT -> if (target == "apply_font") {
                if (s.value >= 28) { mark("applied"); say("已应用。练习文字变大了。") } else say("先向右拖动滑块，把字号调到 28 以上。")
            }
            Scene.CARE -> when (target) {
                "toggle" -> { s = s.copy(enabled = !s.enabled); if (s.enabled) mark("simple") }
                "care_toggle" -> { s = s.copy(secondary = !s.secondary); if (s.secondary) mark("care") }
            }
            Scene.INPUT -> when (target) {
                "clear" -> { if (s.text.isNotEmpty()) mark("deleted"); s = s.copy(text = ""); say("已清空。可以重新输入。") }
                "finish_input" -> if (s.text.isNotBlank() && "deleted" in s.achieved) { mark("finished"); say("写好了！输入与删除都练习过了。") } else say("先输入、删除，再重新写一句话。")
            }
            Scene.SEARCH -> when (target) {
                "search" -> {
                    s = s.copy(page = "results", secondary = s.text.trim().isNotEmpty() && "家庭相册".contains(s.text.trim()))
                    mark("searched")
                    if (!s.secondary) say("没有找到匹配内容。试试搜索“相册”。")
                }
                "search_result" -> if (s.page == "results" && s.secondary) { mark("result"); s = s.copy(page = "album"); say("打开了家庭相册。") }
            }
            Scene.CHAT -> if (target == "send") {
                if (s.text.isBlank()) say("输入框还是空的，先写一句话。")
                else { mark("sent"); s = s.copy(messages = s.messages + s.text.trim(), text = ""); say("消息已出现在聊天区。") }
            }
            Scene.PHOTO -> when (target) {
                "open_photo" -> { mark("photo_open"); s = s.copy(page = "photo") }
                "photo_back" -> { if ("zoomed" in s.achieved) mark("photo_back"); s = s.copy(page = "main", zoom = 1f) }
            }
            Scene.SEND_PHOTO -> when (target) {
                "add_photo" -> s = s.copy(page = "attachments")
                "album" -> if (s.page == "attachments") { mark("picker"); s = s.copy(page = "picker") }
                "photo_0", "photo_1", "photo_2" -> if (s.page == "picker") { mark("selected"); s = s.copy(selected = target.last().digitToInt()) }
                "send_photo" -> if (s.page == "picker" && s.selected != null) { mark("photo_sent"); s = s.copy(page = "main", secondary = true); say("照片已发送给虚构的“家人”。") } else say("先选择一张照片，再点发送。")
                "back" -> s = s.copy(page = "main")
            }
            Scene.SCAN -> when (target) {
                "more" -> s = s.copy(page = "menu")
                "scan" -> if (s.page == "menu") {
                    mark("scan_menu")
                    if (s.permission == true) s = s.copy(page = "scanner") else s = s.copy(dialog = "permission")
                }
                "allow" -> { mark("scan_allowed"); s = s.copy(permission = true, dialog = null, page = "scanner") }
                "deny" -> { s = s.copy(permission = false, dialog = null, page = "main"); say("已拒绝，暂时无法扫码。可以重新进入扫一扫，再决定是否允许。") }
                "scan_code" -> if (s.permission == true && s.page == "scanner") { mark("scan_result"); s = s.copy(page = "result"); say("示例结果：欢迎来到社区图书角。这是一段文字。") }
            }
            Scene.INSTALL -> when (target) {
                "install" -> { mark("installed"); s = s.copy(installed = true); say("示例软件已安装。") }
                "uninstall" -> if (s.installed) s = s.copy(dialog = "uninstall")
                "confirm" -> if (s.dialog == "uninstall" && s.installed) { mark("uninstalled"); s = s.copy(installed = false, dialog = null); say("已卸载示例软件。") }
                "cancel" -> { s = s.copy(dialog = null); say("已取消，软件仍然安装着。") }
            }
        }
        if (s == state.copy(feedback = "")) say("这一步没有改变设置。可以看看上方目标，再试一次。")
        return s
    }
}
